local love = require("love")
function love.conf(t)
    t.title = "StorageInfo"
    t.version = "11.5"
end